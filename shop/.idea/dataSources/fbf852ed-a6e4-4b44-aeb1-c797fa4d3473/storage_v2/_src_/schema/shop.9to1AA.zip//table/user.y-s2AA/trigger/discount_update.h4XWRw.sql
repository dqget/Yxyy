create trigger discount_update
  before UPDATE
  on user
  for each row
  BEGIN
IF NEW.monetary<1000 THEN
SET  new.discount =10;
	ELSEIF NEW.monetary >= 1000 and NEW.monetary < 5000 THEN	
		 SET  new.discount =9;
	ELSEIF NEW.monetary >= 5000 THEN
		 SET  NEW.discount = 8;
	END IF;
END;

